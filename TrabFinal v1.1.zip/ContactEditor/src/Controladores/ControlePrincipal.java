package Controladores;

import Entidades.Imovel;
import Limites.*;

public class ControlePrincipal {
    
    private ControleImovel objCtrImovel;
    private ControlePessoa objCtrPessoa;
    private LimitePrincipal objLimPrincipal;
    private ControleVenda objCtrVenda;

    public ControlePrincipal() {
        objLimPrincipal = new LimitePrincipal(this);
        
        try{
        objCtrPessoa = new ControlePessoa();
        objCtrImovel = new ControleImovel();
        objCtrVenda = new ControleVenda();
        }
        
        catch(Exception e){
            System.out.println("erro na abertura de arquivo");
        }

    }
    
    public void salvaSessao() throws Exception{
        objCtrPessoa.gravaPessoas();
        objCtrImovel.gravaImovel();
        objCtrVenda.gravaVendas();
    }
    
    public void saida(){
        new LimiteSaida(this);
    }
    
    public void cadVendedor(){
        new LimiteCadVendedor(objCtrPessoa);
    }
    
    public void cadComprador(){
        new LimiteCadComprador(objCtrPessoa);
    }
    
    public void cadImovel(){
        new LimiteCadImovel(objCtrImovel, objCtrPessoa.getListaPessoas());
    }
    
    public void showPessoas(){
        new LimiteShowPessoas(objCtrPessoa);
    }
    
    public void cadCorretor(){
        new LimiteCadCorretor(objCtrPessoa);
    }
    
    public void showImoveis(){
        new LimiteShowImoveis(objCtrImovel, this);
    }
    
    public void agendaVisita(Imovel i){
        new LimiteCadVisita(objCtrImovel, objCtrPessoa, i);
    }
    
    public void cadastraProposta(Imovel i){
        new LimiteCadProposta(objCtrImovel, objCtrPessoa, i);
    }
    
    public void showPropostas(){
        new LimiteShowPropostas(objCtrImovel, this);
    }
    
    public void showFaturamento(){
        new LimiteFaturamento(objCtrVenda);
    }
    
    public void showFatCorretor(){
        new LimiteFaturamentoCorretor(objCtrVenda);
    }
    
    public void showVisitasCorretor(){
        new LimiteShowVisitas(objCtrImovel);
    }
    
    public void showTodasVisitas(){
        new LimiteShowTodasVisitas(objCtrImovel);
    }

    public ControleImovel getObjCtrImovel() {
        return objCtrImovel;
    }

    public ControlePessoa getObjCtrPessoa() {
        return objCtrPessoa;
    }

    public LimitePrincipal getObjLimPrincipal() {
        return objLimPrincipal;
    }

    public ControleVenda getObjCtrVenda() {
        return objCtrVenda;
    }
    
    
}
