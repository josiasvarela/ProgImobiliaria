package Controladores;

import Entidades.Comprador;
import Entidades.Corretor;
import Entidades.Imovel;
import Entidades.Proposta;
import Entidades.Vendedor;
import Entidades.Visita;
import Limites.LimiteJulgaProposta;
import Limites.LimiteMostraImovel;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Calendar;

public class ControleImovel {

    private ArrayList<Imovel> listaImovel = new ArrayList();
    private final String arquivo = "Imoveis.dat";

    public ControleImovel() throws Exception {
        recuperaImovel();
    }

    public void addImovel(int codigo, String tipo, String descricao, String foto, double preco, double comissao, Calendar dataInclusao, Vendedor vendedor) {
        listaImovel.add(new Imovel(codigo, tipo, descricao, foto, preco, comissao, dataInclusao, vendedor));
    }

    public void addVisita(Imovel i, Calendar data, Comprador comprador, Corretor corretor) {
        Visita v = new Visita(data, comprador, corretor);
        for (Imovel p : listaImovel) {
            if (p == i) {
                p.agendaVisita(v);
            }
        }
    }

    public void addProposta(Imovel i, Calendar data, Comprador comprador, Corretor corretor, double valor) {
        Proposta p = new Proposta(data, comprador, corretor, valor);
        for(Imovel a: listaImovel){
            if(i == a){
                a.registraProposta(p);
            }
        }
    }

    public void gravaImovel() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream(arquivo);
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listaImovel);
        objOS.flush();
        objOS.close();
    }

    public void recuperaImovel() throws Exception {
        File objFile = new File(arquivo);
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream(arquivo);
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listaImovel = (ArrayList<Imovel>) objIS.readObject();
            objIS.close();
        }
    }

    public void mostraImovel(Imovel i, ControlePrincipal p) {
        new LimiteMostraImovel(i, p);
    }
    
    public void julgaProposta(Imovel i, ControleVenda v){
        new LimiteJulgaProposta(i, v);
    }

    public ArrayList<Imovel> getListaImovel() {
        return listaImovel;
    }

}
