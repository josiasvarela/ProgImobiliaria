
package Controladores;

import Entidades.Corretor;
import Entidades.Imovel;
import Entidades.Pessoa;
import Entidades.Proposta;
import Entidades.Venda;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ControleVenda {
    
    private ArrayList<Venda> listaVendas = new ArrayList();
    private final String arquivo = "Vendas.dat";
    
    public ControleVenda() throws Exception{
        recuperaVendas();
    }
    
    public void addVenda(Imovel i, Proposta p){
        listaVendas.add(new Venda(i,p));
    }

    public ArrayList<Venda> getListaVendas() {
        return listaVendas;
    }
    
    
    
     public void gravaVendas() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream(arquivo);
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listaVendas);
        objOS.flush();
        objOS.close();
    }

    public void recuperaVendas() throws Exception {
        File objFile = new File(arquivo);
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream(arquivo);
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listaVendas = (ArrayList<Venda>) objIS.readObject();
            objIS.close();
        }
    }
    
}
