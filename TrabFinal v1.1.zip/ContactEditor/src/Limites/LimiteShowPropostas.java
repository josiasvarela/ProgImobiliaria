package Limites;

import Controladores.ControleImovel;
import Controladores.ControlePrincipal;
import Entidades.Imovel;
import Entidades.Proposta;
import Entidades.Util;

import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class LimiteShowPropostas extends javax.swing.JFrame {

    private ControleImovel objCtr;
    private ControlePrincipal objCtrPrincipal;

    public LimiteShowPropostas(ControleImovel objCtr, ControlePrincipal objCtrPrincipal) {
        this.objCtr = objCtr;
        this.objCtrPrincipal = objCtrPrincipal;
        initComponents();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        lista = new javax.swing.JList();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Imovéis com proposta pendentes");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        lista.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(lista);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Imóveis com Propostas Pendentes");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(71, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        
        lista.removeAll();
        DefaultListModel listModel = new DefaultListModel();
        ArrayList<Imovel> array = new ArrayList();

        for (Imovel i : objCtr.getListaImovel()) {
            if (i.getEstado().equalsIgnoreCase(Util.ATIVO) && !i.getListaPropostas().isEmpty()) {
                for (Proposta p : i.getListaPropostas()) {
                    if (p.getEstado().equalsIgnoreCase(Util.SUBMEDITA)) {
                        listModel.addElement("Código: " + i.getCodigo() + "    Descrição: " + i.getDescricao());
                        array.add(i);
                        break;
                    }
                }

            }
        }

        lista.setModel(listModel);
        lista.addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (e.getValueIsAdjusting()) {
                    if (lista.getSelectedIndex() != -1) {
                        int index = 0;
                        index = lista.getSelectedIndex();
                        objCtr.julgaProposta(array.get(index), objCtrPrincipal.getObjCtrVenda());
                    }

                }
            }
        });
    }//GEN-LAST:event_formWindowOpened


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList lista;
    // End of variables declaration//GEN-END:variables
}
