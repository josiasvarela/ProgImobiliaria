
package Entidades;

import java.io.Serializable;
import java.util.Calendar;

public class Venda implements Serializable {
    private Imovel imovel;
    private Calendar dataVenda;
    private Proposta proposta;

    public Venda(Imovel imovel, Proposta proposta){
        this.imovel = imovel;
        this.dataVenda = Calendar.getInstance();
        this.proposta = proposta;
    }

    public Imovel getImovel() {
        return imovel;
    }

    public Calendar getDataVenda() {
        return dataVenda;
    }

    public Proposta getProposta() {
        return proposta;
    }
    
    
    
}
